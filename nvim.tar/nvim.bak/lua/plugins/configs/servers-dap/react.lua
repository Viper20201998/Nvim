local dap = require "dap"
dap.adapters.chrome = {
  type = "executable",
  command = "chrome-debug-adapter",
}

dap.configurations.javascriptreact = { -- change this to javascript if needed
  {
    name = "react remote",
    type = "chrome",
    request = "attach",
    program = "${file}",
    cwd = vim.fn.getcwd(),
    sourceMaps = true,
    protocol = "inspector",
    port = 9222,
    webRoot = "${workspaceFolder}",
  },
}
