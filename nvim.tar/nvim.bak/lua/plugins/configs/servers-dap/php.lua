---@diagnostic disable
local dap = require "dap"

dap.adapters.php = {
  type = "executable",
  command = "php-debug-adapter",
}

dap.configurations.php = {
  {
    type = "php",
    request = "launch",
    name = "run current script",
    port = 9000,
    program = "${file}",
    cwd = "${workspaceFolder}",
    runtimeExecutable = "php",
  },
  {
    type = "php",
    request = "launch",
    name = "listen address",
    port = 9000,
  },
}
