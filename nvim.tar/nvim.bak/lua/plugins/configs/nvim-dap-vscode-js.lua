return function()
  require("dap-vscode-js").setup {
    debugger_cmd = { "js-debug-adapter" },
    adapters = { "chrome", "pwa-node", "pwa-chrome", "pwa-msedge", "node-terminal", "pwa-extensionHost" },
  }
end
