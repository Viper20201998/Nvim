return {
  icons = require "user.configs.heirline.icons",
  heirline = require "user.configs.heirline.heirline",
  plugins = {
    require "user.configs.plugins",
  },
  colorscheme = "tokyonight-storm",
}
