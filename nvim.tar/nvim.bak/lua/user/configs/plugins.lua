return {
  require "user.configs.heirline.plugins",
  require "user.configs.snippets.plugins",
  require "user.configs.cmp-cmdline.cmdline",
  require "user.configs.colorsheme.colorsheme",
  require "user.configs.prettier.plugins",
  require "user.configs.surround.plugins",
}
