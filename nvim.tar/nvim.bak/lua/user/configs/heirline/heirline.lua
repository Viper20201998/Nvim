return {
  separators = {
    left = { "", " " },
    right = { " ", "" },
    tab = { "", "" },
  },
  colors = function(hl)
    local get_hlgroup = require("astronvim.utils").get_hlgroup
    local comment_fg = get_hlgroup("comment").fg
    hl.git_branch_fg = comment_fg
    hl.git_added = comment_fg
    hl.git_changed = comment_fg
    hl.git_removed = comment_fg
    hl.blank_bg = get_hlgroup("folded").fg
    hl.file_info_bg = get_hlgroup("visual").bg
    hl.nav_icon_bg = get_hlgroup("string").fg
    hl.nav_fg = hl.nav_icon_bg
    hl.folder_icon_bg = get_hlgroup("error").fg
    return hl
  end,
  attributes = {
    mode = { bold = true },
  },
  icon_highlights = {
    file_icon = {
      statusline = true,
    },
  },
}
