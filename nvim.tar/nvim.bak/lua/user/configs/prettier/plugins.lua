return {
  "MunifTanjim/prettier.nvim",
  event = "VeryLazy",
  opts = {},
  config = function(_, opts) require("prettier").setup(opts) end,
}
