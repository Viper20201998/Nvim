local pickers = require "telescope.pickers"
local finders = require "telescope.finders"
local sorters = require "telescope.sorters"
local actions = require "telescope.actions"
local action_state = require "telescope.actions.state"
local jobid

local function execute_command(prompt_bufnr)
  local selection = action_state.get_selected_entry(prompt_bufnr)
  actions.close(prompt_bufnr)

  -- Crea una nueva pestaña y un buffer para la salida
  vim.cmd "tabnew"
  local buf = vim.api.nvim_get_current_buf()

  -- Ejecuta el comando en segundo plano
  jobid = vim.fn.jobstart(selection.value, {
    on_stdout = function(j, data, _)
      if data[1] ~= nil then
        -- Obtiene las líneas actuales del buffer
        local lines = vim.api.nvim_buf_get_lines(buf, 0, -1, false)

        -- Añade la nueva salida al final del buffer
        table.insert(lines, data[1])
        vim.api.nvim_buf_set_lines(buf, 0, -1, false, lines)
      end
    end,
  })
end

-- Define 'command_picker' en el ámbito global
_G.command_picker = function()
  local commands = {
    "yarn dev",
    "yarn build",
    "strapi develop",
    -- Agrega aquí los comandos que quieras
  }

  pickers
    .new({}, {
      prompt_title = "Comandos personalizados",
      finder = finders.new_table {
        results = commands,
        entry_maker = function(entry)
          return {
            value = entry,
            display = entry,
            ordinal = entry,
          }
        end,
      },
      sorter = sorters.get_generic_fuzzy_sorter(),
      attach_mappings = function(_, map)
        map("i", "<CR>", execute_command)
        map("n", "<CR>", execute_command)
        return true
      end,
    })
    :find()
end

-- Asigna la función a una tecla, por ejemplo <leader>cc
vim.api.nvim_set_keymap("n", "<leader>nnn", "<cmd>lua _G.command_picker()<cr>", { noremap = true, silent = true })
